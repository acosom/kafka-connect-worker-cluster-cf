#!/usr/bin/env bash

# Args that can be passed
main() {
  # Set timeout to 1min
  cf config --async-timeout 1

  local username=""
  local password=""
  local bootstrap_servers=""
  local workercount=0
  local domainname=""
  local orgname=""
  local spacename=""

  while [ $# -gt 0 ]; do
    case "$1" in
      --username*|-u*)
        if [[ "$1" != *=* ]]; then shift; fi
        username="${1#*=}"
        ;;
      --password*|-p*)
        if [[ "$1" != *=* ]]; then shift; fi
        password="${1#*=}"
        ;;
      --bootstrapservers*|-b*)
        if [[ "$1" != *=* ]]; then shift; fi
        bootstrap_servers="${1#*=}"
        ;;
      --workercount*|-c*)
        if [[ "$1" != *=* ]]; then shift; fi
        workercount="${1#*=}"
        ;;
      --domainname*|-d*)
        if [[ "$1" != *=* ]]; then shift; fi
        domainname="${1#*=}"
        ;;
      --orgname*|-o*)
        if [[ "$1" != *=* ]]; then shift; fi
        orgname="${1#*=}"
        ;;
      --spacename*|-s*)
        if [[ "$1" != *=* ]]; then shift; fi
        spacename="${1#*=}"
        ;;

      --help|-h)
        printf "./pushworkers --username someUsername --password somePassword --servers someString.aws.confluent.cloud:9092 --workercount 3 --domainname exivo.link --orgname exivo-dev --spacename test"
        exit 0
        ;;
      *)
        >&2 printf "Error: Invalid argument\n"
        exit 1
        ;;
    esac
    shift
  done

  # Validate arguments
  ge_assert_set username
  ge_assert_set password
  ge_assert_set bootstrap_servers
  ge_assert_not_0 workercount
  ge_assert_set domainname
  ge_assert_set orgname
  ge_assert_set spacename

  # Check if cluster isn't already deployed
  echo "Verifying if cluster has already been deployed"
  cf_curl "/v3/routes?hosts=kafka-connect-$spacename"
  routeGuid=$( echo "$result" | jq -r '.resources[] | .guid' )
  ge_exit_if_not_set routeGuid

  # Define workers
  echo "Defining workers"
  workers=()
  for ((i=0; i<$workercount; ++i)); do
      workers+=("worker$i")
  done


  # Deployment
  echo "Starting deployment of cluster with $workercount workers"
  local result=""
  for workername in "${workers[@]}"
  do
    echo "..Deployment of worker $workername"
    # Deploy the worker
    echo "...Push worker"
    cf_cli push kafka-connect-"$spacename"-"$workername" --docker-image robfdormakaba/kafka-connect-worker:1.0.0 -k 2G -m 2G -u process --no-route

    # Get the APP-GUID of the first worker
    echo "...Get worker guid"
    cf_cli app kafka-connect-"$spacename"-"$workername" --guid
    appGuid=$result

    # Make sure the app listens on both ports: 9092 (kafka broker), 8083 (worker's REST port)
    echo "...Open port 9092, 8080, 8083"
    echo "{\"ports\": [9092, 8080, 8083]}" > payload.json
    cf_curl "/v2/apps/$appGuid" -X PUT -d @payload.json

    # Now create a new internal app-to-app route for which we forward only traffic on the port 8083 for the cluster internal worker nodes.
    ## Create internal app-to-app only route
    echo "...Create internal route"
    cf_cli map-route kafka-connect-"$spacename"-"$workername" apps.internal --hostname kafka-connect-"$spacename"-"$workername"

    ## Get the route-mapping URL
    echo "...Get route-mapping URL"
    cf_curl "/v2/apps/$appGuid/routes"
    routeMappingUrl=$(echo "$result" | jq -r '.resources[] | .entity.route_mappings_url')

    ## Get route_guide from the route-mapping
    # $_:= cf curl /v2/routes/af63546d-5e50-4481-8471-d0a5ba06c63e/route_mappings
    echo "...Get route guid"
    cf_curl "$routeMappingUrl"
    routeGuid=$(echo "$result" | jq '.resources[] | .entity.route_guid')

    ## Make the route forward traffic to port 8083 to the app
    # e.g. cf curl /v2/route_mappings -X POST -d '{"app_guid": "APP-GUID", "route_guid": "ROUTE-GUID", "app_port": 8083}'
    echo "...Add app_port 8083 to routeGuid: $routeGuid"
    echo "{\"app_guid\": \"$appGuid\", \"route_guid\": $routeGuid, \"app_port\": 8083}" > payload.json
    cf_curl "/v2/route_mappings" -X POST -d @payload.json

    # Overwrite the REST settings of the worker
    echo "...Set internal route and port"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_REST_ADVERTISED_HOST_NAME "kafka-connect-$spacename-$workername.apps.internal"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_REST_PORT 8083

    # Overwrite connection settings to the confluent bootstrap servers
    echo "...Set bootstrap servers, security settings"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_BOOTSTRAP_SERVERS "$bootstrap_servers"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_SASL_JAAS_CONFIG "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$username\" password=\"$password\";"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_PRODUCER_SASL_JAAS_CONFIG "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$username\" password=\"$password\";"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_CLIENT_BOOTSTRAP_SERVERS "$bootstrap_servers"
    cf_cli set-env kafka-connect-"$spacename"-"$workername" CONNECT_CLIENT_SASL_JAAS_CONFIG "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$username\" password=\"$password\";"
  done

  # Create external route - to add connectors, read metrics etc. from the outside
  # Since one can do some damage using this route, we'll add private routes instead of security mechanisms so that we only have access from our private network (accessible via VPN)
  cf_curl "/v3/domains?names=$domainname"
  domainGuid=$(echo "$result" | jq -r '.resources[] | .guid' )

  cf_curl "/v3/organizations?names=$orgname"
  orgGuid=$(echo "$result" | jq -r '.resources[] | .guid' )

  cf_curl "/v3/spaces?names=$spacename&organization_guids=$orgGuid"
  spaceGuid=$(echo "$result" | jq -r '.resources[] | .guid' )

  echo "Adding external route kafka-connect-$spacename.$domainname" to org: "$orgname", space: "$spacename"
  echo "{
      \"host\": \"kafka-connect-$spacename\",
      \"relationships\": {
        \"domain\": {
          \"data\": { \"guid\": \"$domainGuid\" }
        },
        \"space\": {
          \"data\": { \"guid\": \"$spaceGuid\" }
        }
      },
      \"metadata\": {
        \"labels\": {},
        \"annotations\": {}
      }
    }" > payload.json
  cf_curl "/v3/routes" -X POST -d @payload.json
  routeGuid=$(echo "$result" | jq -r '.guid' )

  # Route traffic new from external route to any worker (round robin) to port 8083
  echo "Configure destinations for external route with guid $routeGuid"
  destinations="{ \"destinations\": ["
  for i in ${!workers[@]}; do
    workername=${workers[$i]}
    cf_cli app kafka-connect-"$spacename"-"$workername" --guid
    appGuid=$result
    destinations+="{
        \"app\": {
          \"guid\": \"$appGuid\",
          \"process\": {
            \"type\": \"web\"
          }
        },
        \"port\": 8083,
        \"protocol\": \"http1\"
      }"

      len=${#workers[@]}
      pos=$(( i + 1 ))
      if [ $pos -ne $len ]; then
        destinations+=","
      fi
  done
  destinations+="]}"
  echo "$destinations" > payload.json
  cf_curl "/v3/routes/$routeGuid/destinations" -X POST -d @payload.json

  # Cleanup tmp files
  ge_cleanup_tmp_files

  # Configure network policies so that the workers can communicate with each other - workers must be deployed already
  echo "Adding network policies"
  for sourceWorkerName in "${workers[@]}"
  do
    for destinationWorkerName in "${workers[@]}"
    do
      if [ "$sourceWorkerName" != "$destinationWorkerName" ]; then
        cf_cli add-network-policy kafka-connect-"$spacename"-"$sourceWorkerName" --destination-app kafka-connect-"$spacename"-"$destinationWorkerName" --port 8083 --protocol tcp
      fi
    done
    cf_cli restart kafka-connect-"$spacename"-"$sourceWorkerName" &
  done
}

# Helper functions - general
ge_cleanup_tmp_files() {
  rm -rf payload.json
  return 0
}
ge_exit_if_not_set() { [ -n "$( eval echo \$$1 )" ] && echo "Error: Arg $1 already set" && ge_cleanup_tmp_files && exit 0; }
ge_assert_set() { [ -z "$( eval echo \$$1 )" ] && echo "Error: Arg $1 not set" && ge_cleanup_tmp_files && exit 1; }
ge_assert_is_number() {
  local number=$( eval echo \$$1 )
  [ -n "$number" ] && [ "$number" -eq "$number" ] 2> /dev/null
  if [ $? -ne 0 ]; then
    echo "Error Arg $1 is not a number"
    ge_cleanup_tmp_files
    exit 1
  fi
}
ge_assert_not_0() { ge_assert_is_number $1 && [[ "$1" -le 0 ]] && echo "Erorr Arg $1 must be bigger than 0" && ge_cleanup_tmp_files && exit 1; }
ge_abort_on_error() { [ $? -ne 0 ] && tput setaf 1 && printf "$1" && tput sgr0 && ge_cleanup_tmp_files && exit 1; }

cf_cli() {
  IFS=""
  result=""
  local error=""
  cf_cli_response_map "$@"
  ge_abort_on_error "$error"
}
cf_cli_response_map() {
  local response=$(cf "$@" 2>&1)
  if [ $? -ne 0 ] || [[ "$response" =~ (FAILED|failed|Failed) ]]; then
    msg="a problem occurd during the invocation of: cf $@\nSee file error.log for more details.\n"
    printf "$msg\nerror:\n$response\n" > error.log
    error="$msg"
    return 1
  fi
  result="$response"
  return 0
}
cf_curl() {
  IFS=""
  result=""
  local error=""
  cf_curl_response_map "$@"
  ge_abort_on_error "$error"
}
cf_curl_response_map() {
  local response=$(cf curl "$@")
  if [[ "$response" =~ (Error|error|ERROR|errors|Errors|ERRORS) ]]; then
    msg="a problem occurd during the invocation of: $1\nSee file error.log for more details.\n"
    printf "$msg\nerror:\n$response\n\npayload:\n$( cat payload.json )\n" > error.log
    error="$msg"
    return 1
  fi
  result="$response"
  return 0
}

main "$@"
