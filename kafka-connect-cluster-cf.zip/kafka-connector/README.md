# Kafka Connect distributed mode setup and deployment to a PaaS
## Basic Conecepts
Kafka Connect was built to stream events from a source to a sink in a fault tolerant and fast way.

This guide describes the setup of a kafka CDC (change data capture) connector that forwards all events from mongoDB to a kafka topic.

![Screenshot 2021-12-21 at 11.55.53](/assets/Screenshot%202021-12-21%20at%2011.55.53.png)
To set up Kafka connect in a fault tolerant way, we have to deploy multiple worker nodes. Failovers shall happen whenever a node isn't available anymore. For enough availability, we'll set up a 3 node cluster in this guide. A worker node is a consumer of mongoDB change stream events, which it forwards to a Kafka topic.

Important to note here is that the change stream events of mongoDB are fully acked writes to the mongoDB cluster and not writes that are from WAL log - therefore the write-concern is upheld. Thus, we have the guarantee to consume the correct/ consistent events that are written to mongoDB.

We have to deploy multiple worker nodes to form a cluster - a Kafka connect cluster. There is no zookeeper or other components that we have to deploy besides the workers. The workers are using the Kafka consumer API and thus are part of a Kafka consumer group. They are listening to rebalances and react accordingly. When one node becomes unavailable, a rebalance occurs and the polling task might be distributed.

Worker nodes communicate with:
a) Kafka Brokers in Confluent and
b) with each other

![Screenshot 2021-12-21 at 13.06.38](/assets/Screenshot%202021-12-21%20at%2013.06.38.png)

Given a worker or a cluster of workers, we can install a connector plugin onto them.
In our case it is a source-connector plugin that is polling from mongoDB. These plugins are extending the `SourceTask` from kafka-connect itself and return a list of `SourceRecord`s which will underlyingly be passed
to the kafka-connect library. This means that the plugin configures the task to be executed by the library. The library will be handling this task and make sure it runs distributed and fails over to other nodes in case of failure.

Therefore, we must install the connector plugin as well as configure it.
Kafka-connect must store this configs within the cluster so that once a failover happens,
the next worker can continue the work.

A worker plugin usually can be downloaded and installed via the confluent-hub. You can also
download the plugin and place it within the worker's configured `plugin.path`.

If confluent-hub is used, the get installed into a default `plugin.path`.
```docker
ENV CONNECT_PLUGIN_PATH="/usr/share/java, /usr/share/confluent-hub-components"
```
An example of the confluent-hub approach, you can find within the provided Dockerfile in this guide.

If we deploy 3 workers with the connector plugin installed, we end up with the following setup for a cluster:
![Screenshot 2021-12-21 at 14.49.04](/assets/Screenshot%202021-12-21%20at%2014.49.04.png)


Once the worker is correctly configured and has the plugin installed, we can spawn a connector and inherently a task/ multiple tasks will be spawned. Remember, the plugin takes care of creating the tasks. Thus, we just have to spawn a connector with the right configuration. For the mongoDB-source connector plugin just task per collection will be spawned per connector. This is because the mongoDB's
change stream event feature is built such that it scales via sharded collections - which we won't cover for simplicity reasons.

Once we start 3 workers, POST a connector to the worker cluster, we'll end up with the following setup regarding the connectors and tasks.
![Screenshot 2021-12-21 at 15.33.03](/assets/Screenshot%202021-12-21%20at%2015.33.03.png)

Yes you've read correctly, the connector has to (in the distributed mode) be sent via a http POST to the cluster. Therefore, workers must eitehr be reachable from the outside or at least we must be able to SSH's into the worker and send a POST request from there.

e.g.
```bash
curl -X POST -H "Content-Type: application/json" -d @config.json http://localhost:8083/connectors
```

In case we'd for example want to consume from different mongoDB's, we'd have to add one more connector with a different config for the database connection, collection etc.

A full example of a config for a connector can be found in the step by step guide below.

To fully understand what a connector is we now look at a setup of multiple connectors that target two differnet databases (two different mongoDBs).
In theory, we could target multiple collections of each database, but in this guide we chose just one.
![Screenshot 2021-12-21 at 16.03.43](/assets/Screenshot%202021-12-21%20at%2016.03.43.png)

Of course, instead of two mongoDBs, we could install another plugin such as the [Debezium PostgreSQL CDC Source Connector](https://www.confluent.io/hub/debezium/debezium-connector-postgresql) and spawn a connector that uses it to connect to a PostgresSQL database.

### Worker Details
#### Worker's REST API
The REST API of each worker is mainly used to spawn connectors but also to monitor the connectors and tasks. It can also validate connector configs for a connector. Requests to one of the a follower worker, will always be forwarded to the leader.

We have several important endpoints that we'll need for this guide:


```bash
##### Validate a connector config for a specific plugin
curl -X PUT -H "Content-Type: application/json" -d @config.json http://localhost:8083/conntector-plugins/MongoSourceConnector/config/validate

##### Add a connector
curl -X POST -H "Content-Type: application/json" -d @config.json http://localhost:8083/connectors

##### Listing connectors
curl -s -X GET "http://localhost:8083/connectors/"

##### Deleting a connector
curl -s -X DELETE "http://localhost:8083/connectors/name-from-config-json"
```

The whole API you can find here:
https://docs.confluent.io/4.1.0/connect/references/restapi.html

Some more practical examples you can find here:
https://developer.confluent.io/learn-kafka/kafka-connect/rest-api/


#### Why the workers need to communicate with each other
When a worker node joins the cluster, it loads the internal compacted status topic where the current leader url is being stored. The followers always forward the REST requests to the leader. For example when we spawn/ delete a connector a new config must be stored onto the internal config topic. If we'd post the same config for a connector to two follower nodes and the requests wouldn't be routed to the leader, both might add the same connector to the internal config topic and we'd end up with a duplicated connector.
Thus, the requests always get routed to the leader to make sure that we don't end up with incorrect states.
[To see that in code](https://github.com/apache/kafka/blob/99b9b3e84f4e98c3f07714e1de6a139a004cbc5b/connect/runtime/src/main/java/org/apache/kafka/connect/runtime/distributed/DistributedHerder.java#L845)

We therefore have to make sure that the network is configured such that they can communicate. Each worker exposes an advertised host name and port. Each worker can be elect the leader during a rebalance.

The following settings must be added to the config:
```docker
ENV CONNECT_REST_ADVERTISED_HOST_NAME="kafka-connect-worker1.yourdomain.com"
ENV CONNECT_REST_PORT="8083"
```
A complete example you can find below in the step by step guide.

##### Loadbalancer problems
Important to note here is that the workers each must have their own route and no loadbalancer is set in front of them.

If you front your Kafka Connect workers with a load balancer with a random/round-robin policy then you might see the error below occasionally, since some of your requests won't be routed to the leader but instead to the follower. As described above, it would lead to problems consequently the error below will appear.

```json
{"error_code":409,"message":"Cannot complete request because of a conflicting operation (e.g. worker rebalance)"}
```

#### Why the workers talk to the kafka broker besides producing data
In the distributed mode, there obviously must be a way to store state so that all worker nodes can access it.

- The current offset must be stored (where we left of consuming a mongoDB collection for example).
- The config of a connector such that a worker knows where to connect to in case of a failover must be stored.
- The task status along with it's currently assigned worker must be stored.
- The data topic status (for a task) must be stored.
- etc.

Kafka connect currenlty stores this information within 3 internal compacted topics:
```docker
ENV CONNECT_CONFIG_STORAGE_TOPIC="connect-config"
ENV CONNECT_OFFSET_STORAGE_TOPIC="connect-offsets"
ENV CONNECT_STATUS_STORAGE_TOPIC="connect-status"
```


## Connector details
In order to understand the connector config in the step by step guide, we have to cover a few more topics about the connectors.

### Transformations
Each connector connects itself to a data source of a kind. In case of our mongoDB, we can configure the connector in a way such that it retrieves not only the patches of each CRUD operation but the whole document that got inserted / updated/ deleted.

In case of mongoDB though this "full document" comes with a certain structure and surrounding properties. If you decide that you don't need certain properties or that you want certain properties of your full document to be concatenated together in order to form the key, you'll need transformations.

Let's watch (attach to the change stream events) our MongoDB "events" collection.
```js
watchCursor = db.getCollection('events').watch(
   [],
   { fullDocument : "updateLookup" }
);

while (!watchCursor.isExhausted()){
   if (watchCursor.hasNext()){
      printjson(watchCursor.next());
   }
}
```
If we add an event and watch the full document we'll retrieve the following:
```json
{
	"_id" : {
		"_data" : "8261CB1425000000032B022C0100296E5A10043894F093C2C54A54B1265E075C8DAD33463C5F6964003C36316362313432356539643563653030383832343731343630000004"
	},
	"operationType" : "insert",
	"clusterTime" : Timestamp(1640698917, 3),
	"fullDocument" : {
		"_id" : "61cb1425e9d5ce00882471460",
		"streamId" : "c7bf6fb3-1b83-442b-9f80-8fc57ad2ac83",
		"aggregateId" : "c7bf6fb3-1b83-442b-9f80-8fc57ad2ac83",
		"aggregate" : "component",
		"context" : "planning",
		"streamRevision" : 31,
		"commitId" : "61cb1425e9d5ce0088247146",
		"commitSequence" : 0,
		"commitStamp" : ISODate("2021-12-28T13:41:57.142Z"),
		"payload" : {
			"name" : "componentChanged",
			"payload" : {
				"siteId" : "4a48c386-100b-4b23-a39d-6585a6ba790e",
				"identifier" : "Alarm type I",
				"labelling" : "change stream test1",
				"orientationprice" : {
					"amount" : 0
				}
			},
			"aggregate" : {
				"id" : "c7bf6fb3-1b83-442b-9f80-8fc57ad2ac83",
				"name" : "component",
				"revision" : 32
			},
			"correlationId" : "9cda2efd-c8f9-4c66-90c4-84a672f61e21",
			"version" : 0,
			"context" : {
				"name" : "planning"
			},
			"id" : "b8c1390f-b683-4177-92ee-e052340b8b5a",
			"occurredAt" : ISODate("2021-12-28T13:41:57.142Z")
		},
		"position" : null,
		"id" : "61cb1425e9d5ce00882471460",
		"restInCommitStream" : 0,
		"dispatched" : false
	},
	"ns" : {
		"db" : "rs_38b089be-3f80-42a3-b0fe-8c4382ca5c83",
		"coll" : "events"
	},
	"documentKey" : {
		"_id" : "61cb1425e9d5ce00882471460"
	}
}
```
As you can see we have a lot of surrounding properties and maybe even properties missing or just alter that we want to ingest into the data topic in Kafka. We therefore have to add transformations. There are different options how this can be approached.

- We transform the document before retrieval, within MongoDB using pipelines during the `watch`.
- We transform the document after retrieval, within Kafka Connect using the MongoDB plugin.
- We transform the document after retrieval, within Kafka Connect using the built in [SMTs](https://docs.confluent.io/platform/current/connect/transforms/overview.html).
- We transform the document using a combination of the above mentioned.

Be aware that the built in SMT's mostly depend on a schema. MongoDB is mostly used schema-less, thus, if used schema-less, we have to specify or infer a schema in the plugin in order to use them.

Therefore, depending on the plugin you are using, you might be able apply such transformations but this isn't always the case. They're not always well documented and sometimes have to be looked up in the code base / tests of the code base of the plugin.

If our goal would be to generate a nice looking concatenated key from multiple properties within the full document, that we later on can extract for the actual key in Kafka, we could use a MongoDB pipeline transformation that is executed during the `watch` and then use the MongoDB's built in plugin transformation to extract it as the key. We don't need any built in SMT for this.

Given the datastructue above, we'd want to the key to be of the structure: `context_aggregate_aggregateId_eventName`.

For this use case in MongoDB, the dataflow would be as follows:
![Screenshot 2021-12-30 at 12.22.31](/assets/Screenshot%202021-12-30%20at%2012.22.31.png)
[In code: Setup pipeline](https://github.com/mongodb/mongo-kafka/blob/621394f2197e31e0b6b07d8390bf6ee40e8cd501/src/main/java/com/mongodb/kafka/connect/source/MongoSourceTask.java#L619)
[In code: Process next document](https://github.com/mongodb/mongo-kafka/blob/621394f2197e31e0b6b07d8390bf6ee40e8cd501/src/main/java/com/mongodb/kafka/connect/source/MongoSourceTask.java#L203)
[In code: Apply output.schema.key to document](https://github.com/mongodb/mongo-kafka/blob/621394f2197e31e0b6b07d8390bf6ee40e8cd501/src/main/java/com/mongodb/kafka/connect/source/MongoSourceTask.java#L285)

Let's look at how a pipeline works in MongoDB itself:
```js
watchCursor = db.getCollection('events').watch(
   [{
       $addFields : {
         "key" : { "$concat": ["$fullDocument.context", "_", "$fullDocument.aggregate", "_", "$fullDocument.aggregateId", "_", "$fullDocument.payload.name"]}
       }
    }],
   { fullDocument : "updateLookup" }
);

while (!watchCursor.isExhausted()){
   if (watchCursor.hasNext()){
      printjson(watchCursor.next());
   }
}
```

This will give us the same document as above but with a new property "key" on the root level:
```json
{
        ...

	"documentKey" : {
		"_id" : "61cb1795e9d5ce00882471470"
	},
	"key" : "planning_component_c7bf6fb3-1b83-442b-9f80-8fc57ad2ac83_componentChanged"
}
```
We'll have to add this pipeline to our connector config in order to instruct the connector plugin to add it to the `watch` that will be run to stream new documents from within th plugin.

We'll also have to extract this generated property and use it as the key. We can do so via the `output.schema.key`. In order for it to be applied, the `output.format.key` must be set to "schema". Since the key will be of type string, and we want our Kafka key to be a raw string, we can then set the `key.converter` to "StringConverter".
```json
"output.schema.key": "{\"type\" : \"record\", \"name\" : \"key\",\"fields\" : [{\"name\": \"key\", \"type\": [\"string\",  \"null\"]}]}",
"output.format.key": "schema",
"key.converter": "org.apache.kafka.connect.storage.StringConverter",
"key.converter.schemas.enable": false
```

## Step by step deployment guide
We're going to deploy a cluster of worker nodes to a cloud foundry environment. We do so because it shows the steps we need to apply quite comprehensibly. You don't need any knowhow about cloud-foundry to follow this guide.

- We'll use confluent-cloud to set up our Kafka cluster.
- We'll attach to one mongoDB instance.
- We'll apply a pipeline to generate a concatenated key property.
- We'll extract the concatenated key property and use it as the key within the Kafka topic.

### 1 - Setup confluent cloud
Go to confluent cloud https://confluent.cloud/login, if you haven't sign up, and create a basic cluster.

![Screenshot 2021-12-27 at 14.42.17](/assets/Screenshot%202021-12-27%20at%2014.42.17_ftujb1wyk.png)

Be aware that if you run you cluster for longer times with the setup in this guide, some costs might apply because the internal topics use quite an amount of partitions by default.

*As a reference:
Having the following setup running for *~1month* will cost *~70$*.
So you better shut it down if you don't need it or run a Kafka Cluster locally to save some costs.*

e.g. for the internal offset topic:
`offset.storage.topic = default 25 partitions`
*If you choose to create this topic manually, always create it as a compacted, highly replicated (3x or more) topic with a large number of partitions (e.g., 25 or 50, just like Kafka’s built-in __consumer_offsets topic) to support large Kafka Connect clusters.*

For the purpose of our setup we could make the amount of partitions much lower but optimizing the cluster isn't part of this guide. Also, keep in mind the purpose of your cluster. If you'd like to expand, you'll need more partitions.


### 2 - Setup your worker (Dockerfile)
We're going to reuse the `confluentinc/cp-kafka-connect-base` docker image which includes the worker library to build and configure our own docker image for a worker.  These env vars can later on be overwritten by setting env vars of the app.

e.g.
```bash
cf set-env appName CONNECT_REST_PORT 80
```
We'll have to overwrite the ` CONNECT_REST_ADVERTISED_HOST_NAME` AND
`CONNECT_REST_PORT` for each worker later on.

The following `Dockerfile` can be re-used to build your own docker image for a worker.

Create a new directory and save this Dockerfile.
```docker
# Retrieve the base kafka connect image on dockerhub
FROM confluentinc/cp-kafka-connect-base

USER root

# The Kafka broker, you can retrieve the credentials from within confluent cloud
ENV CONNECT_BOOTSTRAP_SERVERS="someId.eu-central-1.aws.confluent.cloud:9092"
ENV CONNECT_SECURITY_PROTOCOL="SASL_SSL"
ENV CONNECT_SASL_JAAS_CONFIG='org.apache.kafka.common.security.plain.PlainLoginModule required username="sumeUserName" password="somePassword";'
ENV CONNECT_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM="https"
ENV CONNECT_SASL_MECHANISM="PLAIN"
ENV CONNECT_CLIENT_BOOTSTRAP_SERVERS="someId.eu-central-1.aws.confluent.cloud:9092"
ENV CONNECT_CLIENT_SECURITY_PROTOCOL="SASL_SSL"
ENV CONNECT_CLIENT_SASL_JAAS_CONFIG='org.apache.kafka.common.security.plain.PlainLoginModule required username="someUserName" password="somePassword";'
ENV CONNECT_CLIENT_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM="https"
ENV CONNECT_PRODUCER_SASL_MECHANISM="PLAIN"
ENV CONNECT_PRODUCER_SECURITY_PROTOCOL="SASL_SSL"
ENV CONNECT_PRODUCER_SASL_JAAS_CONFIG='org.apache.kafka.common.security.plain.PlainLoginModule required username="someUserName" password="somePassword";'

# Specify the plugin path - since we're using a plugin from the confluent hub we have to add its path
ENV CONNECT_PLUGIN_PATH="/usr/share/java, /usr/share/confluent-hub-components"

# The REST settings so that the workers can communicate with each other
ENV CONNECT_REST_ADVERTISED_HOST_NAME="kafka-connect-worker1.intra.exivo.link"
ENV CONNECT_REST_PORT="8083"

# The group setting so that multiple workers form a cluster
ENV CONNECT_GROUP_ID="compose-connect-group"

# The internal topic names, we use the default partition settings
ENV CONNECT_CONFIG_STORAGE_TOPIC="connect-config"
ENV CONNECT_OFFSET_STORAGE_TOPIC="connect-offsets"
ENV CONNECT_STATUS_STORAGE_TOPIC="connect-status"

# The key and value converter so that it can parse the JSON retrieved by MongoDB
ENV CONNECT_KEY_CONVERTER="org.apache.kafka.connect.json.JsonConverter"
ENV CONNECT_VALUE_CONVERTER="org.apache.kafka.connect.json.JsonConverter"

# Speed optimizations to avoid offset commit failures
ENV CONNECT_CONNECTOR_CLIENT_CONFIG_OVERRIDE_POLICY="All"
ENV CONNECT_PRODUCER_BATCH_SIZE=655360
ENV CONNECT_OFFSET_FLUSH_INTERVAL_MS=30000
ENV CONNECT_OFFSET_FLUSH_TIMEOUT_MS=10000

# Install the connector plugin
RUN confluent-hub install --no-prompt mongodb/kafka-connect-mongodb:1.6.1

# Copy the connector configuration
COPY config.json .

# Launch the worker and POST the connector config to the worker node
COPY run.sh /usr/share/java
RUN ["chmod", "+x", "/usr/share/java/run.sh"]
ENTRYPOINT ["/usr/share/java/run.sh"]
```

### 3 - Prepare the connector config (config.json)
As described above, each connector has its own configuration that we can verify and then have to POST. It for example contains the DB connection and the target collection in case of using MongoDB.

The config is a JSON that we'll have to POST to the workers REST endpoint. It will be routed to the leader from where the connector will be spawned.

- The above described transformation `pipeline` as well as the `output.schema.key` will have to be applied in this config.
- We'll also have to add a DB `connection.uri` and `collection` etc.


Copy the following config and create a `config.json` file in the root of the newly created directory and replace the necessary config properties.
```json
{
	"name": "mongo-source-connector",
	"config": {
		"connector.class": "com.mongodb.kafka.connect.MongoSourceConnector",
		"connection.uri": "connectionString...",
		"collection": "events",
		"topic.creation.default.partitions": 1,
		"topic.creation.default.replication.factor": 3,
		"copy.existing": true,
		"topic.prefix": "taibika-domain",
		"publish.full.document.only": true,
		"pipeline": "[{$addFields : { \"key\" : { \"$concat\": [\"$fullDocument.context\", \"_\", \"$fullDocument.aggregate\", \"_\", \"$fullDocument.aggregateId\", \"_\", \"$fullDocument.payload.name\"]}}}]",
		"output.schema.key": "{\"type\" : \"record\", \"name\" : \"key\",\"fields\" : [{\"name\": \"key\", \"type\": [\"string\",  \"null\"]}]}",
		"output.format.key": "schema",
		"key.converter": "org.apache.kafka.connect.storage.StringConverter",
		"key.converter.schemas.enable": false,
		"output.format.value": "json",
		"value.converter": "org.apache.kafka.connect.storage.StringConverter",
		"producer.override.batch.size": "655360",
		"producer.override.buffer.memory": "8388608"
	}
}
```

### 4 - Run the worker and POST the connector config (run.sh)
In order to run the worker, we are going to create a `run.sh` file and save it within the newly created directory. A `sleep infinity` has to be added that prevents the worker from being stopped.

Note that we POST the connector config already here. This isn't the recommended way but the easiest since we're working with a restricted network and we'd therefore have to configure a route that is openly accessible such that we can POST the config. We're going to skip this step for this guide but keep in mind that you probably want to set that up that as a further step and keep in mind that you'll have to add security restrictions as well.

It's content shall be:
```bash
#!/usr/bin/env bash
# Launch the worker
/etc/confluent/docker/run &

# Wait for it to start running
# Change the port here if not using the default
bash -c ' \
echo -e "\n\n=============\nWaiting for Kafka Connect to start listening on localhost ⏳\n=============\n"
while [ $(curl -s -o /dev/null -w %{http_code} http://localhost:8083/connectors) -ne 200 ] ; do
  echo -e "\t" $(date) " Kafka Connect listener HTTP state: " $(curl -s -o /dev/null -w %{http_code} http://localhost:8083/connectors) " (waiting for 200)"
  sleep 5
done
echo -e $(date) "\n\n--------------\n\o/ Kafka Connect is ready! Listener HTTP state: " $(curl -s -o /dev/null -w %{http_code} http://localhost:8083/connectors) "\n--------------\n"

# Now create your connector
echo "Connectors can now be posted to the cluster."
sleep infinity
'
```

### 5 - Build the worker node
Build your image with a tag.
```bash
# Tag build and tage your image
docker build ./ -t username/kafka-connect-worker:1.0.0
# Push your image
docker push username/kafka-connect-worker:1.0.0
# Create a latest alias tag
docker tag username/kafka-connect-worker:1.0.0 username/kafka-connect-worker
docker push username/kafka-connect-worker
```

### 6 - Push your app to the PaaS
We are going to push our image with a container that holds 2GB of memory and 2GB of disk space.
We want to have 3 workers running in order to form our cluster.

For cloud foundry users - you can use the following cli command.
```bash
cf push kafka-connect-mongodb-worker1 --docker-image username/kafka-connect-worker:1.0.0 -k 2G -m 2G -u "process"
cf push kafka-connect-mongodb-worker2 --docker-image username/kafka-connect-worker:1.0.0 -k 2G -m 2G -u "process"
cf push kafka-connect-mongodb-worker3 --docker-image username/kafka-connect-worker:1.0.0 -k 2G -m 2G -u "process"
```
The same can be achieved using Kubernetes or the likes. This is merely for demonstration purposes only.

### 7 - Network communication between the workers
We have to make sure that our deployed worker node app has the ports opened to communicate with

- with Kafka brokers
- with each other

In cloud foundry we'll need to follow the following steps using the cf cli.
```bash
# ---- REPEAT THIS FOR ALL WORKERS ----
# Get the APP-GUID of the first worker
cf app kafka-connect-worker1 --guid
# Make sure the app listens on both ports: 9092 (kafka broker), 8083 (worker's REST port)
cf curl /v2/apps/APP-GUID -X PUT -d '{"ports": [9092, 8083]}'

# Now create a new internal app-to-app route for which we forward only traffic on the port 8083 for the cluster internal worker nodes.
## Create internal app-to-app only route
cf map-route kafka-connect-worker1 apps.internal --hostname kafka-connect-worker1
## Get the route-mapping URL
cf curl /v2/apps/APP-GUID/routes
## Get route_guide from the route-mapping
cf curl /v2/routes/af63546d-5e50-4481-8471-d0a5ba06c63e/route_mappings
## Make the route forward traffic to port 8083 to the app
cf curl /v2/route_mappings -X POST -d '{"app_guid": "APP-GUID", "route_guid": "ROUTE-GUID", "app_port": 8083}'

# Overwrite the REST settings of the worker
cf set-env kafka-connect-worker1 CONNECT_REST_ADVERTISED_HOST_NAME "kafka-worker1.apps.internal"
cf set-env kafka-connect-worker1 CONNECT_REST_PORT 80
# ---- REPEAT THIS FOR ALL WORKERS ----

# We need to add a network policy so that the workers can talk via the internal routes with each other
cf add-network-policy kafka-connect-worker1 --destination-app kafka-connect-worker2 --port 8083 --protocol tcp
cf add-network-policy kafka-connect-worker1 --destination-app kafka-connect-worker3 --port 8083 --protocol tcp
cf add-network-policy kafka-connect-worker2 --destination-app kafka-connect-worker1 --port 8083 --protocol tcp
cf add-network-policy kafka-connect-worker2 --destination-app kafka-connect-worker3 --port 8083 --protocol tcp
cf add-network-policy kafka-connect-worker3 --destination-app kafka-connect-worker1 --port 8083 --protocol tcp
cf add-network-policy kafka-connect-worker3 --destination-app kafka-connect-worker2 --port 8083 --protocol tcp
```

### 8 - Create a public/ external route to POST connector configurations
We have established the routes for the internal communication so that the worker nodes can communicate with each other.
An external route must be added as well so that we can POST our connector configurations etc.
The route will route the traffic in a round robin fashion to one of the workers. The worker will internally within the cluster forward the requests
to the master. In this tutorial we won't add any security but make sure to secure this route in production environments.
```
# Create the external route
echo "{
      \"host\": \"kafka-connect-external\",
      \"relationships\": {
        \"domain\": {
          \"data\": { \"guid\": \"$domainGuid\" }
        },
        \"space\": {
          \"data\": { \"guid\": \"$spaceGuid\" }
        }
      },
      \"metadata\": {
        \"labels\": {},
        \"annotations\": {}
      }
    }" > payload.json

cf curl "/v3/routes" -X POST -d @payload.json

# Add all the destinations of the workers to the external route so the traffic ends up on one of them # in a round robin fashion
destinations="{ \"destinations\": ["
  for i in ${!workers[@]}; do
    workername=${workers[$i]}
    cf app kafka-connect-"$spacename"-"$workername" --guid
    appGuid=$result
    destinations+="{
        \"app\": {
          \"guid\": \"$appGuid\",
          \"process\": {
            \"type\": \"web\"
          }
        },
        \"port\": 8083,
        \"protocol\": \"http1\"
      }"

      len=${#workers[@]}
      pos=$(( i + 1 ))
      if [ $pos -ne $len ]; then
        destinations+=","
      fi
  done
destinations+="]}"
echo "$destinations" > payload.json
cf curl "/v3/routes/$routeGuid/destinations" -X POST -d @payload.json
```

You'll have to repeat this for each of the 3 worker nodes we have pushed.

### 9 - Test your cluster
By stopping an app you can observe rebalances.
If you stop the worker that currently is running the task the task should be taken over by another worker in the cluster - remember, since we have only one collection to be processed it can only be one node currently working.

You can also go to confluent cloud and inspect the internal topics and look at which worker is currently executing this task. This should also change as soon as it fails over to another worker node.
